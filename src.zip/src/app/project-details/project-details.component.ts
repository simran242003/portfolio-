
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.css']
})
export class ProjectDetailsComponent implements OnInit {
  project: any;

  constructor(private route: ActivatedRoute, private http: HttpClient) { }

  ngOnInit(): void {
    const projectId = this.route.snapshot.paramMap.get('id'); //reference: https://stackoverflow.com/questions/70797769/what-is-the-difference-between-this-route-params-and-this-route-snapshot-params

    if (projectId !== null) {
      this.loadProjectDetails(+projectId);
    } else {
      console.error('Project ID is null');
    }
  }

  loadProjectDetails(id: number): void {
    this.http.get<any>('assets/data/projects.json').subscribe(
      data => {
        this.project = data.projectsData.find((p: any) => p.id === id);
      },
      error => console.error('Error loading project details', error)
    );
  }
}
